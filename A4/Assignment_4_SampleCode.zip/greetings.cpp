#include<iostream>
using namespace std;
int main(int argc, char const *argv[])
{
    string name;
    getline(cin, name);
    cout << "Hello " << name << endl;
    return 0;
}

