#include<iostream>
using namespace std;
int main(int argc, char const *argv[])
{
    int num1, num2;
    cin >> num1 >> num2;
    int result = num1 + num2;
    cout << result << endl;
    return 0;
}
